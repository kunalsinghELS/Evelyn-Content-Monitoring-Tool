import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.GeneralSecurityException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Scanner;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.openxml4j.opc.PackageProperties;

public class SystemFiles{
	static ArrayList<String> fileName = new ArrayList();
	static ArrayList<String> filePath = new ArrayList();
	static String[][] arr;
	static SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
	static SimpleDateFormat df1 = new SimpleDateFormat("HH:mm");
	static Calendar calendar = Calendar.getInstance();
	static String nextDate;
	
	public static void main(String args[]) throws IOException
	{
		InputStream is = null;
		BufferedReader br = null;
		String line;
		ArrayList<String> list = new ArrayList<String>();
		try {
			is = SystemFiles.class.getResourceAsStream("/ExecutionTime.txt");
			br = new BufferedReader(new InputStreamReader(is));
			while (null != (line = br.readLine())) {
				list.add(line);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		String executionTime = null;
		Iterator<String> it = list.iterator();
		while (it.hasNext()) {
			// System.out.println(it.next());
			executionTime = it.next().split("-")[1];
		}
		System.out.println("Execution time: " + executionTime);

		System.out.println("time: " + df1.format(new Date()));
		// if ((df1.format(new Date())).equalsIgnoreCase(executionTime)) {
		System.out.println("Inside if:" + df1.format(new Date()));
		calendar.setTime(calendar.getTime());
		calendar.add(Calendar.DAY_OF_YEAR, 1);
		nextDate = df.format(calendar.getTime());
		System.out.println("Run flag is false.");
		// open port and make connection
		// ServerClass sc = new ServerClass();
		UUID uuid = new UUID();
		String systemUUID = UUID.getUUID();
		// String serialNumberCommand = "wmic bios get serialnumber";
		// String systemSerialNumber = getSerialNumber(serialNumberCommand);
		System.out.println("UUID Serial Number: " + systemUUID);

		try {
			startExecution(systemUUID);
		} catch (IOException e) { // TODO Auto-generated catchblock

			e.printStackTrace();
			System.out.println("Start Execution method failed.");
		}
		// }
	}

	/*
	 * private static String getSerialNumber(String serialNumberCommand) throws
	 * IOException { Process p = Runtime.getRuntime().exec(serialNumberCommand);
	 * BufferedReader br = new BufferedReader(new
	 * InputStreamReader(p.getInputStream())); String result = ""; String line;
	 * while ((line = br.readLine()) != null) { result += line; } String
	 * serialNumber = result.split(" ")[2]; // System.out.println(serialNumber);
	 * br.close(); return serialNumber; }
	 */	
	public static void startExecution(String systemSerialNumber) throws IOException
	{
		System.out.println("Execution has been Started!");
		
		String logSpreadsheetName;
		String specificPath;
		
		LogsSpreadsheet ls = new LogsSpreadsheet();
		try {
			ls.execute();
			logSpreadsheetName = "Evelyn Content Monitoring Tool - System UUID and Email ID";
			ls.createLogSpreadsheet(systemSerialNumber);
			File[] drives = File.listRoots();
			for (File adrives : drives) {
				System.out.println("Drive Name: " + adrives);
				specificPath = adrives.getAbsolutePath();
				//specificPath = "C:\\Users\\user\\Desktop\\Nancy\\1CX\\1CX";
				System.out.println("Entered Path: "+specificPath);
				try
				{
					extracteFilesOrFolder(specificPath);
				}
				catch(Exception e)
				{
					System.out.println("File Path Error: "+specificPath);
				}
			}
			// store filename and file path in the array
			arr = new String[fileName.size()][filePath.size()];
			for (int i = 0; i < fileName.size(); i++) {
				arr[i][0] = (String) fileName.get(i);
				arr[i][1] = (String) filePath.get(i);
			}
			// write in user's log spreadsheet
			logSpreadsheetName = "User's Log-" + df.format(new Date());
			ls.createUserLogSpreadsheet(systemSerialNumber, logSpreadsheetName, arr);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (GeneralSecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// extract files from a specific path
	static void extracteFilesOrFolder(String path) {
		File folder = new File(path);
		File[] files = folder.listFiles();
		for (File allFiles : files) {
			String directoryName = null;
			if (allFiles.isDirectory()) {
				System.out.println("Directory Name: " + allFiles.getName());
				directoryName = allFiles.getName();
				
				System.out.println("next date: "+nextDate);
				try {
					if(directoryName.equalsIgnoreCase(df.format(new Date())) 
							|| directoryName.equalsIgnoreCase(nextDate)
							|| directoryName.equalsIgnoreCase("Static Content") 
							|| directoryName.contains("Windows")
							|| directoryName.contains("Program Files")
							)
						System.out.println("Same Date/Static Content Folder");
					else
						extracteFilesOrFolder(allFiles.getAbsolutePath());
				} catch (Exception e) {
					System.out.println("Error at " + e+"\n"+allFiles.getName());
				}
			} else if (allFiles.getName().contains(".docx") || allFiles.getName().contains(".zip")) {
				System.out.println("Zip/Docx File Name: " + allFiles.getName());
				
				String docxFilePath = allFiles.getAbsolutePath();
				try {
					OPCPackage opc = OPCPackage.open(docxFilePath);
					PackageProperties pp = opc.getPackageProperties();
					// System.out.println("Author Name: "+pp.getCreatorProperty().getValue());
					if (pp.getCreatorProperty().getValue().equals("EvelynProprietary")) {
						System.out.println("Deleted Docx File Name: " + allFiles.getName());
						fileName.add(allFiles.getName());
						System.out.println("Deleted Docx File Path: " + allFiles.getAbsolutePath());
						filePath.add(docxFilePath);
						allFiles.deleteOnExit();
					}
					opc.flush();
					opc.close();
				} catch (IOException | InvalidFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	
}
