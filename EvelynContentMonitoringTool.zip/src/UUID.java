import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class UUID {

	public UUID() 
	{
		System.out.println("Constructor called");
		getUUID();
	}

	static String getUUID() {
		System.out.println("Method called");
		StringBuffer output = new StringBuffer();
		String machineID = null;
		try {
			Process serNumProcess = Runtime.getRuntime().exec("wmic csproduct get UUID");
			BufferedReader br = new BufferedReader(new InputStreamReader(serNumProcess.getInputStream()));
			String line="";
			while((line = br.readLine())!=null)
			{
				//System.out.println("Line: "+br.readLine()+"\n "+line);
				output.append(line+"\n");
			}
				
			machineID = output.toString().substring(output.indexOf("\n"),output.length()).trim(); 
			//System.out.println("UUID of the system: "+machineID);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return machineID;
	}
}
