
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class UserEmailID extends Application {
	String userEmailID;


	@Override
	public void start(Stage primaryStage) {
		Label emailID = new Label("Enter your office Email ID: ");
		emailID.setFont(Font.font("Verdana", FontWeight.BOLD, 13));
		
		TextField emailIDTextField = new TextField();
		emailIDTextField.setPrefSize(140, 13);
		emailIDTextField.setPromptText("xyz@evelynlearning.com");
		
		Button btn = new Button("Submit");
		btn.setFont(Font.font("Verdana", FontWeight.BOLD, 13));
		
		HBox hbox = new HBox();
		hbox.getChildren().addAll(emailID, emailIDTextField);
		hbox.setAlignment(Pos.BASELINE_CENTER);
		
		HBox hbox1 = new HBox();
		hbox1.getChildren().add(btn);
		hbox1.setPadding(new Insets(20, 20, 15, 150));
		//hbox1.setAlignment(Pos.BASELINE_CENTER);
		
		VBox vbox = new VBox();
		vbox.getChildren().addAll(hbox, hbox1);
		vbox.setAlignment(Pos.BASELINE_CENTER);
		
		btn.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e)
			{
				if(emailIDTextField.getText().contains("@evelynlearning.com") && !emailIDTextField.getText().isEmpty())
				{
					System.out.println("You pressed submit button."+emailIDTextField.getText());
					LogsSpreadsheet.setEmailID(emailIDTextField.getText());
					primaryStage.close();					
				}
				else
				{
					emailIDTextField.setText("");
					Label errorLabel = new Label();
					errorLabel.setText("Invalid Email ID!!!!");
					errorLabel.setFont(Font.font("Verdana", FontWeight.BOLD, 13));
					errorLabel.setAlignment(Pos.CENTER);
					errorLabel.setTextFill(Color.RED);
					Scene secondViewScene = new Scene(errorLabel, 150, 50);

					Stage newWindow = new Stage();
					newWindow.setTitle("Error");
					newWindow.getIcons().add(new Image(getClass().getResourceAsStream("/evelyn.png")));
					newWindow.setScene(secondViewScene);
					// Specifies the modality for new window.
					newWindow.initModality(Modality.APPLICATION_MODAL);
					// Specifies the owner Window (parent) for new window
					newWindow.initOwner(primaryStage);
					newWindow.setResizable(false);
					newWindow.show();
				}
			}
		});
		
		Scene scene = new Scene(vbox, 350, 70);
		primaryStage.setScene(scene);
		primaryStage.setTitle("Evelyn Monitoring Tool");
		primaryStage.getIcons().add(new Image(getClass().getResourceAsStream("/evelyn.png")));
		primaryStage.setResizable(false);
		primaryStage.show();
	}
	
	
	public void exec()
	{
		launch();
	}
}
