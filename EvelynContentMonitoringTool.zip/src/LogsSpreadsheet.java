import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.DriveScopes;
import com.google.api.services.drive.model.File;
import com.google.api.services.drive.model.FileList;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.SheetsScopes;
import com.google.api.services.sheets.v4.model.Spreadsheet;
import com.google.api.services.sheets.v4.model.SpreadsheetProperties;
import com.google.api.services.sheets.v4.model.ValueRange;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.GeneralSecurityException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class LogsSpreadsheet {
    private static final String APPLICATION_NAME = "Monitoring Tool Logs";
    private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();
    private static final String Sheet_TOKENS_DIRECTORY_PATH = "sheetTokens";

    private static final String Drive_TOKENS_DIRECTORY_PATH = "driveTokens";
    static String emailID_ColB = "";
    /**
     * Global instance of the scopes required by this quickstart.
     * If modifying these scopes, delete your previously saved tokens/ folder.
     */
    private static final List<String> sheetsSCOPES = Collections.singletonList(SheetsScopes.SPREADSHEETS);
    private static final List<String> driveSCOPES = Collections.singletonList(DriveScopes.DRIVE_READONLY);
    
    private static final String CREDENTIALS_FILE_PATH = "/credentials.json";

    /**
     * Creates an authorized Credential object.
     * @param HTTP_TRANSPORT The network HTTP Transport.
     * @param string 
     * @return An authorized Credential object.
     * @throws IOException If the credentials.json file cannot be found.
     */
    private static Credential getSheetCredentials(final NetHttpTransport HTTP_TRANSPORT) throws IOException {
        // Load client secrets.
        InputStream in = LogsSpreadsheet.class.getResourceAsStream(CREDENTIALS_FILE_PATH);
        if (in == null) {
            throw new FileNotFoundException("Resource not found: " + CREDENTIALS_FILE_PATH);
        }
        GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));
        GoogleAuthorizationCodeFlow flow;
        // Build flow and trigger user authorization request.
        flow = new GoogleAuthorizationCodeFlow.Builder(
                    HTTP_TRANSPORT, JSON_FACTORY, clientSecrets, sheetsSCOPES)
                    .setDataStoreFactory(new FileDataStoreFactory(new java.io.File(Sheet_TOKENS_DIRECTORY_PATH)))
                    .setAccessType("offline")
                    .build();
        
        LocalServerReceiver receiver = new LocalServerReceiver.Builder().setPort(8888).build();
        return new AuthorizationCodeInstalledApp(flow, receiver).authorize("user");
    }
    
    /**
     * Creates an authorized Credential object.
     * @param HTTP_TRANSPORT The network HTTP Transport.
     * @return An authorized Credential object.
     * @throws IOException If the credentials.json file cannot be found.
     */
    private static Credential getDriveCredentials(final NetHttpTransport HTTP_TRANSPORT) throws IOException {
        // Load client secrets.
        InputStream in = LogsSpreadsheet.class.getResourceAsStream(CREDENTIALS_FILE_PATH);
        if (in == null) {
            throw new FileNotFoundException("Resource not found: " + CREDENTIALS_FILE_PATH);
        }
        GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));

        // Build flow and trigger user authorization request.
        GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(
                HTTP_TRANSPORT, JSON_FACTORY, clientSecrets, driveSCOPES)
                .setDataStoreFactory(new FileDataStoreFactory(new java.io.File(Drive_TOKENS_DIRECTORY_PATH)))
                .setAccessType("offline")
                .build();
        LocalServerReceiver receiver = new LocalServerReceiver.Builder().setPort(8888).build();
        return new AuthorizationCodeInstalledApp(flow, receiver).authorize("user");
    }

    /**
     * Prints the names and majors of students in a sample spreadsheet:
     * https://docs.google.com/spreadsheets/d/1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms/edit
     * @param ipaddress 
     * @param uuid 
     */
    
    NetHttpTransport HTTP_TRANSPORT;
    Sheets sheetsService;
    Drive driveService;
    void  execute() throws IOException, GeneralSecurityException {
        // Build a new authorized API client service.
    	HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
	    sheetsService = new Sheets.Builder(HTTP_TRANSPORT, JSON_FACTORY, getSheetCredentials(HTTP_TRANSPORT))
                .setApplicationName(APPLICATION_NAME)
                .build();
	    
	    driveService = new Drive.Builder(HTTP_TRANSPORT, JSON_FACTORY, getDriveCredentials(HTTP_TRANSPORT))
                .setApplicationName(APPLICATION_NAME)
                .build(); 
       }

	public void createLogSpreadsheet(String systemSerialNumber) throws IOException {
		// check spreadsheet name exists or not
        // = getSpreadsheetID(driveService, logSpreadsheetName);
		String spreadsheetID = "1u6M4moImTNx9Ga6OfmlL6z1gH6HJT_PrPSYr0pRTjno";
		System.out.println("Spreadsheet is already exists.");
    	ValueRange ipAddressUUIDResponse = null;
    	boolean flag = false;
		while (flag == false) {
			ipAddressUUIDResponse = sheetsService.spreadsheets().values()
					.get(spreadsheetID, "Sheet1!A:B").execute();
			flag = true;
		}
		System.out.println(ipAddressUUIDResponse);
        List<List<Object>> uuidColumnValues = ipAddressUUIDResponse.getValues();
        System.out.println(uuidColumnValues.size());
        boolean uuidFlag = false;
        for(int i=0; i<uuidColumnValues.size(); i++)
        {
        	String uuid_ColA = (String) uuidColumnValues.get(i).get(0);
        	System.out.println("UUiD from column: "+uuid_ColA);
        	emailID_ColB = (String) uuidColumnValues.get(i).get(1); 
        	System.out.println("Email from Column: "+emailID_ColB);
        	if(uuid_ColA.equalsIgnoreCase(systemSerialNumber))
        	{
        		System.out.println("Found the uuid");
        		System.out.println("writing at row-" + (i+1));
        		writeIPAddressSerialNumber(systemSerialNumber, emailID_ColB, spreadsheetID, sheetsService, i+1);
        		uuidFlag = true;
                break;
        	}
        }
        
        if(!uuidFlag)
    	{
        	System.out.println("Not Found");
        	Scanner input = new Scanner(System.in);
        	UserEmailID ueid = new UserEmailID();
        	ueid.exec();
        	System.out.println("Email id from other class: "+emailID_ColB);
        	//System.exit(0);
			/*
			 * System.out.println("Enter your email id: ");
			 *  emailID_ColB= input.next();
			 */
        	int lastrowofIPAddressUUIDResponse = uuidColumnValues.size() + 1;
			System.out.println("Size of the sheet1: " + lastrowofIPAddressUUIDResponse);
			
        	writeIPAddressSerialNumber(systemSerialNumber, emailID_ColB, spreadsheetID, sheetsService, lastrowofIPAddressUUIDResponse);
    	}
        
		/*
		 * if(spreadsheetID == null) {
		 * System.out.println("There is no existing spreadsheet with the name");
		 * Spreadsheet spreadsheet = new Spreadsheet(); spreadsheet.setProperties(new
		 * SpreadsheetProperties().setTitle(logSpreadsheetName)); spreadsheet =
		 * sheetsService.spreadsheets().create(spreadsheet).setFields("spreadsheetId").
		 * execute(); System.out.println("Spreadsheet Id: "+spreadsheetID);
		 * spreadsheetID = spreadsheet.getSpreadsheetId();
		 * 
		 * // write first row heading (UUID and IP Address) List<List<Object>>
		 * writeHeadingRow = Arrays.asList(Arrays.asList("UUID", "IP Address"));
		 * ValueRange valueBody = new ValueRange().setValues(writeHeadingRow);
		 * 
		 * boolean flag = false; while (flag == false) {
		 * sheetsService.spreadsheets().values().update(spreadsheetID, "Sheet1!A1",
		 * valueBody) .setValueInputOption("RAW").execute(); flag = true; }
		 * 
		 * ValueRange ipAddressUUIDResponse = null; boolean flag1 = false; while (flag1
		 * == false) { // get the last row of the spreadsheet. ipAddressUUIDResponse =
		 * sheetsService.spreadsheets().values() .get(spreadsheetID,
		 * "Sheet1!A:A").execute(); flag1 = true; } List<List<Object>> uuidColumnValues
		 * = ipAddressUUIDResponse.getValues(); int lastrowofIPAddressUUIDResponse =
		 * uuidColumnValues.size() + 1; System.out.println("Size of the sheet1: " +
		 * lastrowofIPAddressUUIDResponse); writeIPAddressUUID(uuid, ipaddress,
		 * spreadsheetID, sheetsService, lastrowofIPAddressUUIDResponse); } else {
		 * System.out.println("Spreadsheet is already exists."); ValueRange
		 * ipAddressUUIDResponse = null; boolean flag = false; while (flag == false) {
		 * ipAddressUUIDResponse = sheetsService.spreadsheets().values()
		 * .get(spreadsheetID, "Sheet1!A:A").execute(); flag = true; }
		 * List<List<Object>> uuidColumnValues = ipAddressUUIDResponse.getValues();
		 * 
		 * for(int i=1; i<uuidColumnValues.size(); i++) { String uuid_ColA = (String)
		 * uuidColumnValues.get(i).get(0);
		 * System.out.println("UUiD from column: "+uuid_ColA);
		 * if(uuid_ColA.equalsIgnoreCase(uuid)) { System.out.println("Found the uuid");
		 * System.out.println("writing at row-" + (i+1)); writeIPAddressUUID(uuid,
		 * ipaddress, spreadsheetID, sheetsService, i+1); break; } else { int
		 * lastrowofIPAddressUUIDResponse = uuidColumnValues.size() + 1;
		 * System.out.println("Size of the sheet1: " + lastrowofIPAddressUUIDResponse);
		 * writeIPAddressUUID(uuid, ipaddress, spreadsheetID, sheetsService,
		 * lastrowofIPAddressUUIDResponse); } } }
		 */
	}

	private void writeIPAddressSerialNumber(String systemSerialNumber, String emailID, String spreadsheetID, Sheets sheetsService, int lastrowofIPAddressUUIDResponse) throws IOException {
		// create a new spreadsheet with title of current date
		List<List<Object>> writeReportDate = Arrays.asList(Arrays.asList(systemSerialNumber, emailID));
		ValueRange databody = new ValueRange().setValues(writeReportDate);
		boolean flag = false;
		while (flag == false) {
			sheetsService.spreadsheets().values()
					.update(spreadsheetID, "Sheet1!A" + lastrowofIPAddressUUIDResponse, databody)
					.setValueInputOption("RAW").execute();
			flag = true;
		}
	}

	private String getSpreadsheetID(Drive driveService, String logSpreadsheetName) throws IOException {
		String spreadsheetID = null;
		FileList result = null;
		boolean flag = false;
		while (flag == false) 
		{
			result = driveService.files().list().setFields("nextPageToken, files(id, name)").execute();
			flag = true;
		}
        List<File> files = result.getFiles();
        if (files == null || files.isEmpty()) {
            System.out.println("No files found.");
        } else {
            System.out.println("Files:");
            for (File file : files) {
                if(file.getName().equalsIgnoreCase(logSpreadsheetName))
                {
                	System.out.println("Same spreadsheet exists");
                	//System.out.println("Spreadsheet Name: "+file.getName()+" and Spreadsheet Id: "+file.getId());
                	spreadsheetID = file.getId();
                }
            }
        }
        return spreadsheetID;
	}

	public void createUserLogSpreadsheet(String uuid, String logSpreadsheetName, String[][] arr)
			throws IOException {
		String spreadsheetID = getSpreadsheetID(driveService, logSpreadsheetName);
		int lastrowofUserLogResponse = 0;
		if (spreadsheetID == null) {
			System.out.println("There is no existing deleted log spreadsheet with the name");
			Spreadsheet spreadsheet = new Spreadsheet();
			spreadsheet.setProperties(new SpreadsheetProperties().setTitle(logSpreadsheetName));
			spreadsheet = sheetsService.spreadsheets().create(spreadsheet).setFields("spreadsheetId").execute();
			System.out.println("Spreadsheet Id: " + spreadsheetID);
			spreadsheetID = spreadsheet.getSpreadsheetId();
			
			ValueRange valueBody = null;
			
			boolean valueBodyFlag = false;
			while(valueBodyFlag  == false)
			{
				// write first row heading (UUID and IP Address)
				List<List<Object>> writeHeadingRow = Arrays
						.asList(Arrays.asList("System Serial Number (BIOS)", "Email", "File Name", "File Path"));
				valueBody = new ValueRange().setValues(writeHeadingRow);
				valueBodyFlag = true;
			}
			boolean flag = false;
			while (flag == false) {
				sheetsService.spreadsheets().values().update(spreadsheetID, "Sheet1!A1", valueBody)
						.setValueInputOption("RAW").execute();
				flag = true;
			}
			
			ValueRange ipAddressUUIDResponse = null;
			boolean flag1 = false;
			while (flag1 == false) {
				// get the last row of the spreadsheet.
				ipAddressUUIDResponse = sheetsService.spreadsheets().values()
						.get(spreadsheetID, "Sheet1!A:A").execute();
				flag1 = true;
			}
			
			List<List<Object>> userLogColumnValues = ipAddressUUIDResponse.getValues();
			lastrowofUserLogResponse = userLogColumnValues.size() + 1;
			System.out.println("Size of the User Delted Log sheet: " + lastrowofUserLogResponse);
			writeUserLogData(uuid, emailID_ColB, spreadsheetID, sheetsService, lastrowofUserLogResponse, arr);

		} else {
			System.out.println("deleted log spreadsheet is already exists.");
			System.out.println("SpreadsheetID: " + spreadsheetID);
			List<List<Object>> userLogColumnValues = null;
			boolean userLogColumnValuesFlag = false;
			while(userLogColumnValuesFlag == false)
			{
				ValueRange ipAddressUUIDResponse = sheetsService.spreadsheets().values()
						.get(spreadsheetID, "Sheet1!A:A").execute();
				userLogColumnValues = ipAddressUUIDResponse.getValues();
				userLogColumnValuesFlag = true;
			}
			
			lastrowofUserLogResponse = userLogColumnValues.size() + 1;
			writeUserLogData(uuid, emailID_ColB, spreadsheetID, sheetsService, lastrowofUserLogResponse, arr);

		}
	}

	private void writeUserLogData(String uuid, String emailID, String spreadsheetID, Sheets sheetsService2,
			int lastrowofIPAddressUUIDResponse, String[][] arr) throws IOException {
		// TODO Auto-generated method stub
		System.out.println("Spreadsheet ID: "+spreadsheetID);
		System.out.println("Writing email id:");
		System.out.println("Array: "+arr.length);
		for(int x = 0; x<arr.length; x++)
		{
			System.out.println("Writing deelted file data");
			ValueRange databody = null;
			boolean databodyFlag = false;
			while(databodyFlag == false)
			{
				List<List<Object>> writeReportDate = Arrays.asList(Arrays.asList(uuid, emailID, arr[x][0], arr[x][1]));
				databody = new ValueRange().setValues(writeReportDate);
				databodyFlag = true;
			}
			
			boolean flag = false;
			while (flag == false) {
				
				sheetsService2.spreadsheets().values()
						.update(spreadsheetID, "Sheet1!A" + lastrowofIPAddressUUIDResponse, databody)
						.setValueInputOption("RAW").execute();
				flag = true;
			}
			System.out.println("Writing done");
			lastrowofIPAddressUUIDResponse++;
		}
		
	}

	public static void setEmailID(String text) {
		// TODO Auto-generated method stub
		System.out.println("Email id: "+text);
		emailID_ColB = text;
		System.out.println(emailID_ColB);
	}
}