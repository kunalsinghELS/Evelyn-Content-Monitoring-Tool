/* Read input from STDIN. Print your output to STDOUT*/

import java.io.*;
import java.util.*;
public class CandidateCode {
	
    // Driver program to test above function
    public static void main(String[] args)
    {
    	Scanner sc = new Scanner(System.in);
    	String input = sc.nextLine();
        
    	String[] words = input.split("\\s");
    	String result="";
    	for(int i = words.length-1; i>=0; i--)
    	{
    		if(i==words.length)
    			result = result + words[i];
    		else
    			result = result + words[i] +" ";
    		
    	}
    	System.out.println(result);
    }
}
