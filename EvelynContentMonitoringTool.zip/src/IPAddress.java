import java.net.InetAddress;
import java.net.UnknownHostException;

public class IPAddress 
{
	IPAddress()
	{
		getIPAddress();
	}
	
	static String getIPAddress() {
		String ipAddress = null;
		try {
			InetAddress localHost = InetAddress.getLocalHost();
			ipAddress = (localHost.getHostAddress()).trim();
			//System.out.println("System IP Address: "+ipAddress);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ipAddress;
	}
}
